package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.CustSearch;
import com.util.DbUtil;

public class CustSearchDAO {

	public List<CustSearch> vehicleSearch(CustSearch cs) throws SQLException {
		// TODO Auto-generated method stub
		
		;
		
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<CustSearch> vheList=new ArrayList<>();
		 
		try
		{
			 con=DbUtil.getConnection();
		     System.out.println(con);
		     ps=con.prepareStatement("select * from vehicle_search where manufacturer_name=? and ex_showroom_pricevehicle_search between ? and ? and color=? and Seating_capacity=? and branch=? and stock>0");
		     ps.setString(1, cs.getManufactureName());
		     ps.setInt(2, cs.getPricemin());
		     ps.setInt(3, cs.getPricemax());
		     ps.setString(4, cs.getColor());
		     ps.setInt(5, cs.getSeatCapacity());
		     ps.setString(6, cs.getbLocation());
		     
		     rs=ps.executeQuery();
		     while(rs.next())
		     {
		    	 CustSearch css=new CustSearch();
		    	 css.setVehicleId(rs.getString(1));
		    	 css.setManufactureName(rs.getString(3));
		    	 css.setPricemin(rs.getInt(4));
		    	 css.setPricemax(rs.getInt(4));
		    	 css.setColor(rs.getString(5));
		    	 css.setSeatCapacity(rs.getInt(6));
		    	 css.setbLocation(rs.getString(7));
		    	 
		    	 vheList.add(css);
		     }
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			con.close();
		}
		return vheList;
	}

}
