package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.Luser;
import com.util.DbUtil;

public class NewRegisterDAO 
{
	

	public boolean newRegisterUser(Luser luser) throws SQLException {
		// TODO Auto-generated method stub
         boolean flag=false;
		
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try
		{
			
			//Luser us=new Luser();
			con=DbUtil.getConnection();
			ps=con.prepareStatement("insert into users values(?,?,?)");
			ps.setInt(1, luser.getUserId());
			ps.setString(2, luser.getPassword());
			ps.setString(3, luser.getRole());
			if(ps.executeUpdate()>0)
				flag=true;
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			con.close();
		}
		return flag;
		
	}
	

}
