package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.Luser;
import com.util.DbUtil;

public class LoginDAO 
{

	
	public boolean loginUser(Luser luser) throws SQLException {
		// TODO Auto-generated method stub
		
		boolean flag=false;
		
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try
		{
			
			//Luser us=new Luser();
			con=DbUtil.getConnection();
			ps=con.prepareStatement("Select * from users where user_id=? and password=? and role=?");
			ps.setInt(1, luser.getUserId());
			ps.setString(2, luser.getPassword());
			ps.setString(3, luser.getRole());
			rs=ps.executeQuery();
			if(rs.next())
			{
				//System.out.println("found");
				flag=true;
				
			}
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			con.close();
		}
		return flag;
	}

		public boolean CheckStatus(Luser lus) throws SQLException {
boolean flag=false;
		
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;

		try
		{
			
			con=DbUtil.getConnection();
			ps=con.prepareStatement("Select * from customer where user_id=? and status='approved'");
			ps.setInt(1, lus.getUserId());
			rs=ps.executeQuery();
			if(rs.next())
			{
				//System.out.println("found");
				flag=true;
				
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			con.close();
		}
		return flag;
	}

		public boolean bCheckStatus(Luser luser) throws SQLException {
			// TODO Auto-generated method stub
			boolean flag=false;
			
			Connection con=null;
			PreparedStatement ps=null;
			ResultSet rs=null;

			try
			{
				
				con=DbUtil.getConnection();
				ps=con.prepareStatement("Select * from branch_admin where user_id=? and status='approved'");
				ps.setInt(1, luser.getUserId());
				rs=ps.executeQuery();
				if(rs.next())
				{
					//System.out.println("found");
					flag=true;
					
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			finally
			{
				con.close();
			}
			return flag;
		}
	
}
