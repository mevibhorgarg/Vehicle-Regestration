package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.bookings;
import com.util.DbUtil;

public class bookingsDAO {
	
	public boolean insertBooking(List<bookings> blist)
	{
		java.sql.Connection con=null;
		   PreparedStatement p=null;
		   //ResultSet r=null;
	   boolean flag=false;
	   try {
	   con=DbUtil.getConnection();
	     System.out.println(con);
	      
	      for(bookings ob : blist)
	      {
	     p=con.prepareStatement("insert into booking_status values(?,?,?)");
	        p.setInt(1,ob.getUser_id());
	        p.setString(2,ob.getVehicle_id());
	            p.setString(3,"Pending");
	            
	          int  r= p.executeUpdate();
	            if(r>0)
	            {            	System.out.println("row found");
	                  flag=true;
	            }
	      }}
	      catch (ClassNotFoundException e) {
	            System.out.println(e.getMessage());
	      }
	      catch (SQLException e) {
	            System.out.println(e.getMessage());
	      }
	   
	      return flag;
	}
	public boolean featchBookings (int userId) throws SQLException
	{
		boolean flag=false;
		
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try
		{
			
			//Luser us=new Luser();
			con=DbUtil.getConnection();
			ps=con.prepareStatement("Select * from customer where user_id=?");
			ps.setInt(1, userId);
			rs=ps.executeQuery();
			if(rs.next())
			{
				//System.out.println("found");
				flag=true;
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			con.close();
		}
		return flag;
		
	}
	
	public List<bookings> getBookingList(int var) throws SQLException {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<bookings> lb=new ArrayList<>();
		try
		{
			
			//Luser us=new Luser();
			con=DbUtil.getConnection();
			ps=con.prepareStatement("Select * from booking_status where user_id=?");
			ps.setInt(1, var);
		
			rs=ps.executeQuery();
			
			
			
			while(rs.next())
			{
				//System.out.println("found");
				bookings b=new bookings();
				b.setUser_id(rs.getInt(1));
				b.setVehicle_id(rs.getString(2));
				b.setStatus(rs.getString(3));
				lb.add(b);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			con.close();
		}
		return lb;
	}
	public List<bookings> featchRequest(int var) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag=false;
		
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<bookings> lb=new ArrayList<>();
		try
		{
			
			
			con=DbUtil.getConnection();
			ps=con.prepareStatement
("Select bs.user_id, bs.vehicle_id, bs.status from branch_admin ba join vehicle_search vs join booking_status bs on ba.branch_admin_id=vs.branch_admin_id and vs.vehicle_id=bs.vehicle_id where ba.user_id=? and bs.status='pending'");
			ps.setInt(1, var);		
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				
				bookings b=new bookings();
				b.setUser_id(rs.getInt(1));
				b.setVehicle_id(rs.getString(2));
				b.setStatus(rs.getString(3));
				lb.add(b);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			con.close();
		}
		return lb;
	}
	public boolean updateBookedStatus(String vid[],int var)
	{
		java.sql.Connection con=null;
		   PreparedStatement p=null;
		   //ResultSet r=null;
		   int res=0;
		   int count=0;
	   boolean flag=false;
	   try {
	   con=DbUtil.getConnection();
	     System.out.println(con);
	      
	      
	     p=con.prepareStatement("update  booking_status bs join vehicle_search vs join branch_admin ba on bs.vehicle_id=vs.vehicle_id and vs.branch_admin_id=ba.branch_admin_id set bs.status='approve' where ba.user_id=? and bs.vehicle_id=?;");
	     p.setInt(1,var);
	     for(String s:vid)
	     {
	    	 p.setString(2,s);
	    	 res=p.executeUpdate();
	    	 if(res>0)
	    		 count++;
	    	 
	     }
	     if(count==vid.length)
	    	 flag=true;
	     deductStockInVehicle(vid, var);
	     }
	     

	   catch(SQLException e)
	   {}
	   catch(ClassNotFoundException e)
	   {}
	   return flag;
	}
	public boolean deductStockInVehicle(String vid[],int var)
	{
		java.sql.Connection con=null;
		   PreparedStatement p=null;
		   //ResultSet r=null;
		   int res=0;
		   int count=0;
	   boolean flag=false;
	   try {
	   con=DbUtil.getConnection();
	     System.out.println(con);
	      
	      
	     p=con.prepareStatement("update  booking_status bs join vehicle_search vs join branch_admin ba on bs.vehicle_id=vs.vehicle_id and vs.branch_admin_id=ba.branch_admin_id set vs.stock=vs.stock-1 where ba.user_id=? and bs.vehicle_id=?;");
	     p.setInt(1,var);
	     for(String s:vid)
	     {
	    	 p.setString(2,s);
	    	 res=p.executeUpdate();
	    	 if(res>0)
	    		 count++;
	    	 
	     }
	     if(count==vid.length)
	    	 flag=true;
	     }
	     

	   catch(SQLException e)
	   {}
	   catch(ClassNotFoundException e)
	   {}
	   return flag;
	}
	
}
	
