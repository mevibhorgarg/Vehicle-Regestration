package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.NewVehicle;
import com.util.DbUtil;

public class NewVehicleDAO {

	
	public boolean addNewVehicle(NewVehicle nv) {
		// TODO Auto-generated method stub
		
boolean flag=false;
		
		Connection con=null;
		PreparedStatement p=null;
		ResultSet rs=null;
		try {
			   con=DbUtil.getConnection();
			     System.out.println(con);
			      
			      
			     p=con.prepareStatement("insert into vehicle_search values(?,?,?,?,?,?,?,?)");
			        p.setString(1,generateVId());
			        p.setString(2,nv.getBranchAdminId());
			            p.setString(3,nv.getMname());
			            p.setInt(4,nv.getPrice());
			            p.setString(5,nv.getColor());
			            p.setInt(6,nv.getSeatCapacity());
			            p.setString(7,nv.getbLoc());
			            p.setInt(8, 10);
			            
			          int  r= p.executeUpdate();
			            if(r>0)
			            {            	//System.out.println("row found");
			                  flag=true;
			            }
			      }
			      catch (ClassNotFoundException e) {
			            System.out.println(e.getMessage());
			      }
			      catch (SQLException e) {
			            System.out.println(e.getMessage());
			      }
			      return flag;
		
	}
	public String generateVId () throws SQLException
	{
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String finalId = "";
		int count=0;
		int varId=001;
		try
		{
			
			//Luser us=new Luser();
			con=DbUtil.getConnection();
			ps=con.prepareStatement("Select count(*) from vehicle_search");
			
			rs=ps.executeQuery();
			if(rs.next())
			count=rs.getInt(1);
			if(count==0)
				 finalId = "v"+varId;
			else{
				varId=varId+count;
			finalId= "v"+varId;
			}
			

		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			con.close();
		}
		return finalId;
	}

}
