package com.model;

public class NewVehicle {
	private String vid;
	private String branchAdminId;
	private String mname;
	private int price;
	private String color;
	private int seatCapacity;
	private String bLoc;
	public String getVid() {
		return vid;
	}
	public void setVid(String vid) {
		this.vid = vid;
	}
	public String getBranchAdminId() {
		return branchAdminId;
	}
	public void setBranchAdminId(String branchAdminId) {
		this.branchAdminId = branchAdminId;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getSeatCapacity() {
		return seatCapacity;
	}
	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}
	public String getbLoc() {
		return bLoc;
	}
	public void setbLoc(String bLoc) {
		this.bLoc = bLoc;
	}
	public NewVehicle(String vid, String branchAdminId, String mname,
			int price, String color, int seatCapacity, String bLoc) {
		super();
		this.vid = vid;
		this.branchAdminId = branchAdminId;
		this.mname = mname;
		this.price = price;
		this.color = color;
		this.seatCapacity = seatCapacity;
		this.bLoc = bLoc;
	}
	
	
	

}
