package com.model;

import java.sql.SQLException;

import com.dao.LoginDAO;

public class LoginBO {
	
	

	public boolean loginUser(Luser luser) {
		// TODO Auto-generated method stub
		
		LoginDAO loginDAO=new LoginDAO();
		boolean result=false;
		
		try {
			result=loginDAO.loginUser(luser);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public boolean CheckStatus(Luser luser) {
		LoginDAO loginDAO=new LoginDAO();
		boolean result=false;
		
		try {
			result=loginDAO.CheckStatus(luser);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public boolean bCheckStatus(Luser luser) {
		// TODO Auto-generated method stub
		LoginDAO loginDAO=new LoginDAO();
		boolean result=false;
		
		try {
			result=loginDAO.bCheckStatus(luser);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}
