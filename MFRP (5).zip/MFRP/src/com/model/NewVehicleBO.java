package com.model;

import com.dao.NewVehicleDAO;

public class NewVehicleBO {

	
	public boolean addNewVehicle(NewVehicle nv) {
		// TODO Auto-generated method stub
		NewVehicleDAO nvdao=new NewVehicleDAO();
		boolean b=nvdao.addNewVehicle(nv);
		return b;
	}
	

}
