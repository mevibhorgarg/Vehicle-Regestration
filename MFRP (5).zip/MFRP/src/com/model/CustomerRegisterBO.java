package com.model;

import java.sql.SQLException;
import java.util.List;

import com.dao.CustomerRegDAO;

public class CustomerRegisterBO {
	
	public boolean insertValues(CustomerRegister ob)
	{
		CustomerRegDAO usd = new CustomerRegDAO();
		boolean b = usd.insertCust(ob);
		return b;
	}
	public List<CustomerRegister> CList () throws SQLException
	{
		CustomerRegDAO usd = new CustomerRegDAO();
		List<CustomerRegister> customerList= usd.fetchCList();
		return customerList;
		
	}
	
	public boolean updadeCust(String[] cid) {
		// TODO Auto-generated method stub
		CustomerRegDAO usd = new CustomerRegDAO();
		boolean b=usd.updateCustomerStatus(cid);
		return b;
	}
	

}
