package com.model;

import java.sql.SQLException;

import com.dao.requestStockDAO;


public class requestStockBO {

	
	public boolean requestStock(requestStock rss) {
		// TODO Auto-generated method stub
		requestStockDAO rsdao=new requestStockDAO();
		boolean b=rsdao.requestStock(rss);
		return b;
	}

	public java.util.List<requestStock> featchStockReq() throws SQLException {
		// TODO Auto-generated method stub
		requestStockDAO reqdao = new requestStockDAO();
		java.util.List<requestStock> list = reqdao.featchStockReq();
		return list;
		
	}

	public boolean updateRequestStock(String[] stid) throws SQLException {
		// TODO Auto-generated method stub
		requestStockDAO rdao = new requestStockDAO();
		boolean flag = rdao.updateRequestStock(stid);
		return flag;
	}
	

}
