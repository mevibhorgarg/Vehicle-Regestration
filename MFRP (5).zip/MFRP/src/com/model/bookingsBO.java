package com.model;

import java.sql.SQLException;
import java.util.List;

import com.dao.bookingsDAO;

public class bookingsBO {
	public boolean insertBooking(List<bookings> blist)
	{
		bookingsDAO bdao=new bookingsDAO();
		boolean flag = bdao.insertBooking(blist);
		return flag;
	}
	
	
	public List<bookings> getBookingList(int var) throws SQLException
	{
		bookingsDAO bdao=new bookingsDAO();
		List<bookings> flag = bdao.getBookingList(var);
		return flag;
	}


	public List<bookings> featchRequest(int var) throws SQLException {
		// TODO Auto-generated method stub
		
		bookingsDAO bdao=new bookingsDAO();
		List<bookings> flag = bdao.featchRequest(var);
		
		return flag;
		
	}
	public boolean updateBookedStatus(String veid[],int var)
	{
		bookingsDAO bdao=new bookingsDAO();
		boolean flag = bdao.updateBookedStatus(veid,var);
		return flag;
	}
	
	

}
