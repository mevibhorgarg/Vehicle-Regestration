package com.model;

public class requestStock {
	private String stockId;
	private String vid;
	private String mname;
	private int price;
	private String color;
	private int seatCapacity;
	private String bLocation;
	
	
	
	
	public String getStockId() {
		return stockId;
	}
	public void setStockId(String stockId) {
		this.stockId = stockId;
	}
	public String getVid() {
		return vid;
	}
	public void setVid(String vid) {
		this.vid = vid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getSeatCapacity() {
		return seatCapacity;
	}
	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}
	public String getbLocation() {
		return bLocation;
	}
	public void setbLocation(String bLocation) {
		this.bLocation = bLocation;
	}
	public requestStock(String stockId, String vid, String mname, int price,
			String color, int seatCapacity, String bLocation) {
		super();
		this.stockId = stockId;
		this.vid = vid;
		this.mname = mname;
		this.price = price;
		this.color = color;
		this.seatCapacity = seatCapacity;
		this.bLocation = bLocation;
	}

	public requestStock()
	{
		
	}
	

}
