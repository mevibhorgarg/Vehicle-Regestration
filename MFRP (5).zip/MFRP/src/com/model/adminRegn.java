package com.model;

public class adminRegn {
	private int adminId;
	private String password;
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public adminRegn(int adminId, String password) {
		super();
		this.adminId = adminId;
		this.password = password;
	}
	public adminRegn()
	{
		
	}

}
