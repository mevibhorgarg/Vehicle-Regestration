package com.model;

import java.sql.SQLException;
import java.util.List;

import com.dao.CustSearchDAO;

public class CustSearchBO 
{
	public List<CustSearch> vehicleSearch(CustSearch cs) throws SQLException
	{
		CustSearchDAO csdao=new CustSearchDAO();
		List<CustSearch> vheList=csdao.vehicleSearch(cs);
		return vheList;
	}

}
