package com.model;

import java.util.Date;

public class CustomerRegister {
	private String customerId;
	private int userId;
	private String customerName;
	private Date DOB;
	private String address;
	private String email;
	private String phoneNo;
	private String occupation;
	private String status;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	

	
	
	
	
	public CustomerRegister(String customerId, String customerName, Date dOB,
			String address, String email, String phoneNo, String occupation, String status) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		DOB = dOB;
		this.address = address;
		this.email = email;
		this.phoneNo = phoneNo;
		this.occupation = occupation;
		
		this.status = status;
	}
	public CustomerRegister()
	{
		
	}
	

}
