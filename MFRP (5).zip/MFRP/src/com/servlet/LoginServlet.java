package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.BranchAdminDAO;
import com.dao.CustomerRegDAO;
import com.model.LoginBO;
import com.model.Luser;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("skdjbokagn");
		PrintWriter out=response.getWriter();
		String  var=request.getParameter("uid");
		int userId = Integer.parseInt(var);
		String password=request.getParameter("pwd");
		String role=request.getParameter("role");
		
		RequestDispatcher dispatcher=null;
		Luser luser=new Luser(userId,password,role);
		LoginBO l=new LoginBO();
		HttpSession session=request.getSession();
		boolean res=l.loginUser(luser);
		if(res)
		{
			if(role.equals("Customer"))
			{
			CustomerRegDAO custreg = new CustomerRegDAO();
			boolean result=false;
			try {
				 result = custreg.checkCustomer(userId);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(!result)
			{
				session.setAttribute("uid", luser.getUserId());
				dispatcher=request.getRequestDispatcher("customerRegistration.jsp");
				dispatcher.include(request, response);
			}
			else
			{
				LoginBO lo=new LoginBO();
				boolean r=lo.CheckStatus(luser);
				if(r)
				{
					session.setAttribute("uid", luser.getUserId());
					dispatcher=request.getRequestDispatcher("customerHome.jsp");
					dispatcher.forward(request, response);
				}
				else
				{
					dispatcher=request.getRequestDispatcher("contactToBranchAdmin.jsp");
					dispatcher.forward(request, response);
				}
			}
			
			}
			else if(role.equals("Branch_Admin"))
			{
				BranchAdminDAO branch = new BranchAdminDAO();
				boolean result = false;
				try {
					 result = branch.checkCustomer(userId);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(!result)
				{
					session.setAttribute("uid", luser.getUserId());
					dispatcher=request.getRequestDispatcher("branchRegister.jsp");
					dispatcher.include(request, response);
				}
				else
				{
					LoginBO lo=new LoginBO();
					boolean r=lo.bCheckStatus(luser);
					if(r)
					{
						session.setAttribute("uid", luser.getUserId());
						dispatcher=request.getRequestDispatcher("branchAdminHome.jsp");
						dispatcher.forward(request, response);
					}
					else
					{
						dispatcher=request.getRequestDispatcher("contactToBranchAdmin.jsp");
						dispatcher.forward(request, response);
					}
				}
				
				
			}
			//out.print("<h3>Welcome to the website!</h3>");
			//dispatcher=request.getRequestDispatcher("WelcomeServlet");
			//request.setAttribute("uname",userId);
			//dispatcher.include(request, response);
		}
		else
		{
			//out.print("<h3>Invalid username or password</h3>");
			request.setAttribute("message", "Invalid username/password");
			dispatcher=request.getRequestDispatcher("login.jsp");
			dispatcher.include(request, response);
		}
		
		out.close();
	}

}
