package com.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.requestStock;
import com.model.requestStockBO;

/**
 * Servlet implementation class requestStockServlet
 */
public class requestStockServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public requestStockServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher req=null;
		String stockId=null;
		String vehicleId=request.getParameter("vid");
		String mname=request.getParameter("mname");
		int price=Integer.parseInt(request.getParameter("price"));
		
		String color=request.getParameter("color");
		int seatCapacity=Integer.parseInt(request.getParameter("seatCapacity"));
		String bloc=request.getParameter("blocation");
		
		requestStock rss=new requestStock(stockId, vehicleId, mname,price,
				color,seatCapacity,bloc );
		requestStockBO rbbo=new requestStockBO();
		boolean b=rbbo.requestStock(rss);
		
		//System.out.println(vehicleId);
		if(b)
		{
			req=request.getRequestDispatcher("requestSuccess.jsp");
			req.forward(request, response);
		}
		else
		{
			req=request.getRequestDispatcher("contactSys.jsp");
			req.forward(request, response);
		}
		//String branchadminid=null;
		
		/*CustSearch cs=new CustSearch(vehicleId,mname,pricemin,pricemax,
				color,seatCapacity,bloc);
		//System.out.println(mname);
		//System.out.println(pricemin);
		//System.out.println(pricemax);
		//System.out.println(seatCapacity);
		CustSearchBO csbo=new CustSearchBO();
		List<CustSearch> vLst=new ArrayList<>();
			try {
				vLst=csbo.vehicleSearch(cs);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(vLst!=null)
			{
				
				request.setAttribute("vehicleList", vLst);
				req=request.getRequestDispatcher("vehicleList.jsp");
				req.forward(request, response);
			}
			else
			{
				
			}*/
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
