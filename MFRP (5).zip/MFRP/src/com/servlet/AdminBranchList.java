package com.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.BranchAdminBO;
import com.model.BranchAdminRegister;
import com.model.CustomerRegister;
import com.model.CustomerRegisterBO;

/**
 * Servlet implementation class AdminCustList
 */
public class AdminBranchList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminBranchList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher=null;
		
		
		BranchAdminBO babo=new BranchAdminBO();
		List<BranchAdminRegister> lst = new ArrayList<>();
		try {
			lst =babo.bList();
			System.out.println(lst.size());
			if(lst!=null)
				request.setAttribute("branchadminlist", lst);
			System.out.println("list from controller="+lst);
			dispatcher = request.getRequestDispatcher("adminListBranchAdmin.jsp");
	         dispatcher.forward(request, response);
		}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
		{
	
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher=null;
		String bid[]=request.getParameterValues("bid");
		/*for(String s:cid)
		{
			
			System.out.println(s);
		}*/
		
		BranchAdminBO crb=new BranchAdminBO();
		boolean res=crb.updadebranch(bid);
		
		if(res)
		{
			dispatcher = request.getRequestDispatcher("successCustUpdate.jsp");
	         dispatcher.forward(request, response);
		}
		else
		{
			dispatcher = request.getRequestDispatcher("failCustUpdate.jsp");
	         dispatcher.forward(request, response);
		}
		
		}

}
