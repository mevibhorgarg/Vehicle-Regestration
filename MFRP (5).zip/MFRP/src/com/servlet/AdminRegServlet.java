package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.adminRegn;
import com.model.adminRegnBO;

/**
 * Servlet implementation class AdminRegServlet
 */
public class AdminRegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminRegServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String  var=request.getParameter("uid");
		int userId = Integer.parseInt(var);
		String password=request.getParameter("pwd");
		adminRegn admin = new adminRegn();
		admin.setAdminId(userId);
		admin.setPassword(password);
		RequestDispatcher dispatcher=null;
		adminRegnBO adminr = new adminRegnBO();
		boolean flag =adminr.loginAdmin(admin) ;
		if(flag)
		{
			dispatcher=request.getRequestDispatcher("adminHome.jsp");
			dispatcher.include(request, response);
		}
		else
		{
			request.setAttribute("message", "Invalid username/password");
			dispatcher=request.getRequestDispatcher("adminLogin.jsp");
			dispatcher.include(request, response);
		}
	}

}
