package com.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.CustomerRegister;
import com.model.CustomerRegisterBO;

/**
 * Servlet implementation class AdminCustList
 */
public class AdminCustList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminCustList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher=null;
		
		
		CustomerRegisterBO userbo = new CustomerRegisterBO();
		List<CustomerRegister> lst = new ArrayList<>();
		try {
			lst = userbo.CList();
			System.out.println(lst.size());
			if(lst!=null)
				request.setAttribute("userlist", lst);
			System.out.println("list from controller="+lst);
			dispatcher = request.getRequestDispatcher("adminListCust.jsp");
	         dispatcher.forward(request, response);
		}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
		{
	
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher=null;
		String cid[]=request.getParameterValues("cid");
		
		/*for(String s:cid)
		{
			System.out.println(s);
		}*/
		
		CustomerRegisterBO crb=new CustomerRegisterBO();
		boolean res=crb.updadeCust(cid);
		
		if(res)
		{
			dispatcher = request.getRequestDispatcher("successCustUpdate.jsp");
	         dispatcher.forward(request, response);
		}
		else
		{
			dispatcher = request.getRequestDispatcher("failCustUpdate.jsp");
	         dispatcher.forward(request, response);
		}
		
		}

}
