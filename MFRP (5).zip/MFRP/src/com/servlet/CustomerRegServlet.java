package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.CustomerRegister;
import com.model.CustomerRegisterBO;

/**
 * Servlet implementation class cRegisterServlet
 */
public class CustomerRegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerRegServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
		CustomerRegister user = new CustomerRegister();
		response.setContentType("text/html");
		RequestDispatcher req=null;
		PrintWriter out = response.getWriter();
		user.setCustomerId(null);
		HttpSession session=request.getSession();
		int userid=(int)session.getAttribute("uid");
		user.setCustomerName(request.getParameter("custName"));
		user.setUserId(userid);
		//System.out.println(request.getParameter("dob"));
		try {
			user.setDOB(sdf.parse(request.getParameter("dob")));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		user.setAddress(request.getParameter("address"));
		user.setEmail(request.getParameter("email"));
		user.setPhoneNo(request.getParameter("phoneNo"));
		user.setOccupation(request.getParameter("occup"));
		
		
		  user.setStatus(null);
		  
		  
		  CustomerRegisterBO csdo = new CustomerRegisterBO();
		  boolean result = csdo.insertValues(user);
		  
		  
		  if(result)
			{
				//out.print("welcome from Login");
				req=request.getRequestDispatcher("login.jsp");
				req.forward(request, response);
			}
		  else
		  {
			  out.print("failed");
			  req=request.getRequestDispatcher("##");
				req.include(request, response);
			
		  }
		  
	}

}
